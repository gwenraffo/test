var APP_DATA = {
  "scenes": [
    {
      "id": "0-an-office-with-a-desk-and-computer-1zdsyf6b",
      "name": "an-office-with-a-desk-and-computer-1zdsyf6b",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1536,
      "initialViewParameters": {
        "yaw": -0.6645908133229739,
        "pitch": 0.08095850080091616,
        "fov": 1.425614444601826
      },
      "linkHotspots": [
        {
          "yaw": -1.5776677741996536e-9,
          "pitch": -7.061185414158899e-9,
          "rotation": 0,
          "target": "1-a-cartoon-of-a-town-mhb7k7ux"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -1.031684612061543,
          "pitch": -0.07179907469048175,
          "title": "Office with Desk",
          "text": "Here is an office with a desk"
        },
        {
          "yaw": 1.6242563059034385,
          "pitch": -0.032720297924592856,
          "title": "Computer",
          "text": "This is a computer"
        },
        {
          "yaw": -2.384402151129315,
          "pitch": -0.005632628029189846,
          "title": "Plants",
          "text": "These are plants"
        }
      ]
    },
    {
      "id": "1-a-cartoon-of-a-town-mhb7k7ux",
      "name": "a-cartoon-of-a-town-mhb7k7ux",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1536,
      "initialViewParameters": {
        "yaw": -1.4125007067887942,
        "pitch": -0.14403662061459244,
        "fov": 1.425614444601826
      },
      "linkHotspots": [
        {
          "yaw": -1.501762976068548,
          "pitch": 0.22812522111363442,
          "rotation": 0,
          "target": "0-an-office-with-a-desk-and-computer-1zdsyf6b"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -1.5043294841385304,
          "pitch": -0.18331344376830927,
          "title": "Seaside Town",
          "text": "This is a seaside town"
        },
        {
          "yaw": 1.310285949612581,
          "pitch": -0.0020880168467130034,
          "title": "Cabin",
          "text": "This is a small cabin"
        },
        {
          "yaw": 3.075563625330479,
          "pitch": -0.3346159642536204,
          "title": "Tree",
          "text": "This is a tree"
        }
      ]
    },
    {
      "id": "2-a-living-room-with-a-couch-and-a-table-y6ie3mpq",
      "name": "a-living-room-with-a-couch-and-a-table-y6ie3mpq",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 384,
      "initialViewParameters": {
        "yaw": -0.13308540407349767,
        "pitch": -0.20489961956500835,
        "fov": 1.425614444601826
      },
      "linkHotspots": [
        {
          "yaw": -0.0379499157457861,
          "pitch": 0.17530975241657742,
          "rotation": 0,
          "target": "1-a-cartoon-of-a-town-mhb7k7ux"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.08001637152342056,
          "pitch": -0.24439961193160897,
          "title": "Living Room",
          "text": "This is a living room"
        },
        {
          "yaw": 1.9467688609702147,
          "pitch": 0.31887040710763515,
          "title": "Guitar",
          "text": "This is a guitar"
        },
        {
          "yaw": -1.4471105623399296,
          "pitch": 0.3712224272648026,
          "title": "Couch",
          "text": "This is a couch"
        }
      ]
    }
  ],
  "name": "Test 05/16/23",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
